<?php
/**
 * Plugin Name:       Ultimate Small Office Timeclock
 * Plugin URI:        https://github.com/al-carolina-sports/smalloffice_timeclock
 * Description:       Ultimate Small Office Timeclock (USOTC): PIN pad and name-list kiosk add-on for USOTC Core. Shared tablets clock employees in and out without a WordPress login, show a live who-is-working board, and let staff suggest punch edits for supervisor approval.
 * Version:           1.10.0
 * Requires at least: 5.0
 * Requires PHP:      7.4
 * Author:            CSS
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       css-timeclock-addon
 *
 * @package CssTimeclockAddon
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CSS_TC_ADDON_VERSION', '1.10.0' );
// Script and stylesheet version: plugin version plus the time this copy was
// installed. Each upload rewrites this file, so browsers and host caches
// (WP Engine) fetch fresh assets after every deploy, not only on a version bump.
define( 'CSS_TC_ADDON_ASSET_VERSION', CSS_TC_ADDON_VERSION . '.' . (int) filemtime( __FILE__ ) );
define( 'CSS_TC_ADDON_FILE', __FILE__ );
define( 'CSS_TC_ADDON_DIR', plugin_dir_path( __FILE__ ) );
define( 'CSS_TC_ADDON_URL', plugin_dir_url( __FILE__ ) );
define( 'CSS_TC_ADDON_BASENAME', plugin_basename( __FILE__ ) );

require_once CSS_TC_ADDON_DIR . 'includes/class-plugin.php';

/**
 * Plugin bootstrap.
 *
 * @return Css_Tc_Plugin
 */
function css_tc_addon() {
	return Css_Tc_Plugin::instance();
}

css_tc_addon();

register_activation_hook( CSS_TC_ADDON_FILE, array( 'Css_Tc_Plugin', 'activate' ) );
register_deactivation_hook( CSS_TC_ADDON_FILE, array( 'Css_Tc_Plugin', 'deactivate' ) );
